package com.example.lmwncryptoappfinal.models

data class Data(
    val coins: ArrayList<Coin>,
    val stats: Stats
)
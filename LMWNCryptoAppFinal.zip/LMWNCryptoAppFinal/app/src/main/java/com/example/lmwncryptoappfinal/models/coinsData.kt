package com.example.lmwncryptoappfinal.models

data class coinsData(
    val data: Data,
    val status: String
)

